const mongoose = require('mongoose');

// Define the schema for the User
const UserSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true, // This field is required
  },
  email: {
    type: String,
    required: true,
    unique: true, // Ensures that no two users can have the same email
  },
  password: {
    type: String,
    required: true,
  },
  // Add more fields if necessary
});

// Export the model
module.exports = mongoose.model('User', UserSchema);